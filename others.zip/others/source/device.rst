====================
Device插件参考手册
====================

.. highlight:: python

:Title: Device插件参考手册
:Author: yourname@mit.org
:Version: 1.0.0
:Update: |date|

.. |date| date::

.. contents::

简介
====

	for test